# Desafio-1

Desafio semanal numero 1 de coderhouse (desarrollo web)

1-Crea un sketch del sitio web con el tema que crearás para tu Proyecto final. Piensa qué secciones podría tener, e incluye un encabezado, un logo y un pie de página.

2-Construye el esqueleto en HTML semánticamente correcto de la sección principal de la WEB, utilizando las etiquetas HTML vistas.

